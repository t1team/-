
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HACKED BY 1945VN TEAM</title>
  <link rel="shortcut icon" type="image/png" href="https://i.imgur.com/VNxYGhO.png"/>
  <style type="text/css">
    * {
        margin: 0;
        padding: 0;
    }

    body{
        background: #000;
    }

    header {
        background-color:rgba(33, 33, 33, 0.9);
        color:#ffffff;
        display:block;
        font: 14px/1.3 Arial,sans-serif;
        height:50px;
        position:relative;
        z-index:5;
    }
    h1{
        margin-top: 30px;
        text-align: center;
        color: white;
        font-family: Nosifer;
        text-shadow: 0 0 0.5em red, 0 0 0.5em red;
    }

    .we-are {
        color: red;
        font-size: 20px;
        text-shadow: #000 2px 2px 2px;
        letter-spacing: 2px;
    }

    .message {
        color: white;
        -webkit-animation: fadeIn 1s ease-in;
        animation: fadeIn 1s ease-in;
    }

    .cn {
        color: white;
        font-size: 14px;
        text-shadow: #000 2px 2px 2px;
        letter-spacing: 2px;
        -webkit-animation: fadeIn 3s ease-in;
        animation: fadeIn 1s ease-in;
    }

    -webkit-@keyframes we-are {
        from {scale: 1.1;}
        to {scale: 0;}
    }

    @keyframes we-are {
        from {scale: 1.1;}
        to {scale: 0;}
    }

    -webkit-@keyframes fadeIn {
       0% {opacity: 0;}
       100% {opacity: 1;}
    } 

    @keyframes fadeIn {
       0% {opacity: 0;}
       100% {opacity: 1;}
    } 

    @keyframes move-twink-back {
        from {background-position:0 0;}
        to {background-position:-10000px 5000px;}
    }
    @-webkit-keyframes move-twink-back {
        from {background-position:0 0;}
        to {background-position:-10000px 5000px;}
    }
    @-moz-keyframes move-twink-back {
        from {background-position:0 0;}
        to {background-position:-10000px 5000px;}
    }
    @-ms-keyframes move-twink-back {
        from {background-position:0 0;}
        to {background-position:-10000px 5000px;}
    }

    @keyframes move-clouds-back {
        from {background-position:0 0;}
        to {background-position:10000px 0;}
    }
    @-webkit-keyframes move-clouds-back {
        from {background-position:0 0;}
        to {background-position:10000px 0;}
    }
    @-moz-keyframes move-clouds-back {
        from {background-position:0 0;}
        to {background-position:10000px 0;}
    }
    @-ms-keyframes move-clouds-back {
        from {background-position: 0;}
        to {background-position:10000px 0;}
    }

    .stars, .twinkling, .clouds {
      position:absolute;
      top:0;
      left:0;
      right:0;
      bottom:0;
      width:100%;
      height:100%;
      display:block;
    }

    .stars {
      background:#000 url(http://www.script-tutorials.com/demos/360/images/stars.png) repeat top center;
      z-index:0;
    }

    .twinkling{
      background:transparent url(http://www.script-tutorials.com/demos/360/images/twinkling.png) repeat top center;
      z-index:1;

      -moz-animation:move-twink-back 200s linear infinite;
      -ms-animation:move-twink-back 200s linear infinite;
      -o-animation:move-twink-back 200s linear infinite;
      -webkit-animation:move-twink-back 200s linear infinite;
      animation:move-twink-back 200s linear infinite;
    }

    .clouds{
        background:transparent url(http://www.script-tutorials.com/demos/360/images/clouds3.png) repeat top center;
        background-repeat: no-repeat;
        z-index:3;

      -moz-animation:move-clouds-back 200s linear infinite;
      -ms-animation:move-clouds-back 200s linear infinite;
      -o-animation:move-clouds-back 200s linear infinite;
      -webkit-animation:move-clouds-back 200s linear infinite;
      animation:move-clouds-back 200s linear infinite;
    }

    .container {
      height: 100%;
      width: 100%;
      justify-content: center;
      align-items: center;
      display: flex;
    }
    .text {
      font-weight: 100;
      font-size: 28px;
      color: #FAFAFA;
      font-family: Iceland;
      text-shadow: 0 0 0.5em cyan, 0 0 0.5em cyan;
      
    }
    .dud {
      color: #757575;
    }

    .animation-container {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      z-index: 1;
    }

    .animation-container span {
      color: whitesmoke;
      display: block;
      font-size: 18px;
      font-family: 'Helvetica';
      text-shadow: 0 0 1px white;
      position: absolute;
      user-select: none;
      pointer-events: none;
      cursor: default;
      z-index: 1;
      opacity: 0;
      will-change: transform, opacity;
      animation-timing-function: ease-out;
      animation-name: move;
    }

    @keyframes move {
      0% {
        opacity: 0;
        transform: translateY(100vh);
      }
      25% {
        opacity: 1;
      }
      50% {
        opacity: 1;
      }
      75% {
        opacity: 0;
      }
      100% {
        opacity: 0;
        transform: none;
      }
    }
    .buzz_wrapper{
      position:relative;
      width:100%;
      margin:180px auto;
      background-attachment: fixed;
            background-image: url(http://i.imgur.com/9QpJPlG.jpg);
        background-position: 0 0; 
            background-repeat: no-repeat ;  
            background-size:cover;
            overflow : hidden;
      overflow:hidden;
      padding:100px;
    }
    .scanline{
      width:100%;
      display:block;
      background:#000;
      height:4px;
      position:relative;
      z-index:3;
      margin-bottom:5px;
      opacity:0.1;
    }
    .buzz_wrapper span{
      position:absolute;
      -webkit-filter: blur(1px);
      font-size:30px;
      font-family:'Courier new', fixed;
      font-weight:bold;
    }
    .buzz_wrapper span:nth-child(1){
      color:red;
      margin-left:-2px;
      -webkit-filter: blur(2px);
    }
    .buzz_wrapper span:nth-child(2){
      color:green;
      margin-left:2px;
      -webkit-filter: blur(2px);
    }
    .buzz_wrapper span:nth-child(3){
      color:blue;
      position:20px 0;
      -webkit-filter: blur(1px);
    }
    .buzz_wrapper span:nth-child(4){
      color:#fff;
      -webkit-filter: blur(1px);
      text-shadow:0 0 50px rgba(255,255,255,0.4);
    }
    .buzz_wrapper span:nth-child(5){
      color:rgba(255,255,255,0.4);
      -webkit-filter: blur(15px);
    }

    .buzz_wrapper span{
      -webkit-animation: blur 30ms infinite, jerk 50ms infinite;
    }

    @-webkit-keyframes blur {
      0%   { -webkit-filter: blur(1px); opacity:0.8;}
      50% { -webkit-filter: blur(1px); opacity:1; }
      100%{ -webkit-filter: blur(1px); opacity:0.8; }
    }
    @-webkit-keyframes jerk {
      50% { left:1px; }
      51% { left:0; }
    }
    @-webkit-keyframes jerkup {
      50% { top:1px; }
      51% { top:0; }
    }

    .buzz_wrapper span:nth-child(3){
      -webkit-animation: jerkblue 1s infinite;
    }
    @-webkit-keyframes jerkblue {
      0% { left:0; }
      30% { left:0; }
      31% { left:10px; }
      32% { left:0; }
      98% { left:0; }
      100% { left:10px; }
    }
    .buzz_wrapper span:nth-child(2){
      -webkit-animation: jerkgreen 1s infinite;
    }
    @-webkit-keyframes jerkgreen {
      0% { left:0; }
      30% { left:0; }
      31% { left:-10px; }
      32% { left:0; }
      98% { left:0; }
      100% { left:-10px; }
    }

    .buzz_wrapper .text{
      -webkit-animation: jerkwhole 5s infinite;
      position:relative;
    }
    @-webkit-keyframes jerkwhole {
      30% {  }
      40% { opacity:1; top:0; left:0;  -webkit-transform:scale(1,1);  -webkit-transform:skew(0,0);}
      41% { opacity:0.8; top:0px; left:-100px; -webkit-transform:scale(1,1.2);  -webkit-transform:skew(50deg,0);}
      42% { opacity:0.8; top:0px; left:100px; -webkit-transform:scale(1,1.2);  -webkit-transform:skew(-80deg,0);}
      43% { opacity:1; top:0; left:0; -webkit-transform:scale(1,1);  -webkit-transform:skew(0,0);}
      65% { }
    }
	
  </style>
  <script>
    class TextScramble {
      constructor(el) {
        this.el = el
        this.chars = '!@#$%^&*()_-=+{}:"|<>?,./;'
        this.update = this.update.bind(this)
      }
      setText(newText) {
        const oldText = this.el.innerText
        const length = Math.max(oldText.length, newText.length)
        const promise = new Promise((resolve) => this.resolve = resolve)
        this.queue = []
        for (let i = 0; i < length; i++) {
          const from = oldText[i] || ''
          const to = newText[i] || ''
          const start = Math.floor(Math.random() * 40)
          const end = start + Math.floor(Math.random() * 40)
          this.queue.push({ from, to, start, end })
        }
        cancelAnimationFrame(this.frameRequest)
        this.frame = 0
        this.update()
        return promise
      }
      update() {
        let output = ''
        let complete = 0
        for (let i = 0, n = this.queue.length; i < n; i++) {
          let { from, to, start, end, char } = this.queue[i]
          if (this.frame >= end) {
            complete++
            output += to
          } else if (this.frame >= start) {
            if (!char || Math.random() < 0.28) {
              char = this.randomChar()
              this.queue[i].char = char
            }
            output += `<span class="dud">${char}</span>`
          } else {
            output += from
          }
        }
        this.el.innerHTML = output
        if (complete === this.queue.length) {
          this.resolve()
        } else {
          this.frameRequest = requestAnimationFrame(this.update)
          this.frame++
        }
      }
      randomChar() {
        return this.chars[Math.floor(Math.random() * this.chars.length)]
      }
    }

    const phrases = [
      'Yes, I am a criminal.',
      'My crime is that of curiosity.',
      'My crime is that of judging people by what they say and think, not what they look like.',
      'My crime is that of outsmarting you, something that you will never forgive me for.',
      'I am a hacker, and this is my manifesto.',
      'You may stop this individual, but you cant stop us all...',
      'after all, were all alike.'
    ]

    const el = document.querySelector('.text')
    const fx = new TextScramble(el)

    let counter = 0
    const next = () => {
      fx.setText(phrases[counter]).then(() => {
        setTimeout(next, 1500)
      })
      counter = (counter + 1) % phrases.length
    }

    next()

    'use strict';

    var app = {

      chars: ['PureHackers','Unleashed','127.0.0.1','1337','0x523344','Localhost','Cr4sH CoD3','HACKED!','Security','Breached!','System'],

      init: function () {
        app.container = document.createElement('div');
        app.container.className = 'animation-container';
        document.body.appendChild(app.container);
        window.setInterval(app.add, 100);
      },

      add: function () {
        var element = document.createElement('span');
        app.container.appendChild(element);
        app.animate(element);
      },

      animate: function (element) {
        var character = app.chars[Math.floor(Math.random() * app.chars.length)];
        var duration = Math.floor(Math.random() * 15) + 1;
        var offset = Math.floor(Math.random() * (50 - duration * 2)) + 3;
        var size = 10 + (15 - duration);
        element.style.cssText = 'right:'+offset+'vw; font-size:'+size+'px;animation-duration:'+duration+'s';
        element.innerHTML = character;
        window.setTimeout(app.remove, duration * 1000, element);
      },

      remove: function (element) {
        element.parentNode.removeChild(element);
      },

    };

    document.addEventListener('DOMContentLoaded', app.init);
  </script>
  
</head>
<body>
    <div style="position: fixed; top: 75px; left: -225px; width: 600px; padding: 10px; font-size: 24px; text-align: center; color: white; font-family: 'trebuchet ms', verdana, arial, sans-serif;transform: rotate(-45deg);transform-origin: 50% 0px;-o-transform: rotate(-45deg); -o-transform-origin: 50% 0px;-moz-transform: rotate(-45deg); -moz-transform-origin: 50% 0px; -webkit-transform: rotate(-45deg); -webkit-transform-origin: 50% 0px; background-color: Transparent; border: 1px solid rgb(170, 170, 170); z-index: 9999; opacity: 0.5;"><a href="https://www.facebook.com/bualiemcongnghe" style="text-decoration:none;color:white;">1945VN-TEAM</a></div>
    <div class="stars">
      <center>
        <h1>1945VN-TEAM</h1>
      </center>
    </div>
    <div class="twinkling">
      <center><br><br><br>
        <img src="https://i.imgur.com/VNxYGhO.png" width="250"/><br>
        <div class="container">
          <div class="text"></div>
        </div><br><br><br>
        <font face="Sarpanch" color="white" size"10" class="message">
          |&nbsp;  We are 1945VN-Team <font color="red">We come in peace </font>and This is our response&nbsp;  |
        </font><br>
        <font face="Sarpanch" color="white" size"10" class="message">#Hacker Philippines &bull; We request to stop all your attacks on the Vietnam websites ! <font color="red">Thank you.</font><br><br>
        <font face="Play">
          <p class="we-are"><b>WE <font color="cyan">ARE<font color="white">:</b></p>
        </font>
        <font face="Play" class="cn">
          -= ROX3T5 <font color="cyan">|</font> 0c34n <font color="cyan">|</font> vector (shuu) <font color="cyan">|</font> JookerMoon <font color="cyan">|</font> SNAKE2K1 <font color="cyan">|</font> j4pa0 <font color="cyan">|</font> Moewut <font color="cyan">|</font> zFap <font color="cyan">|</font> CP04042K <font color="cyan">|</font> PassDDos <font color="cyan">|</font> lulzk1d
  =-
        </font>
      </center>
    </div>
    <div class="clouds">
    </div>
    <iframe width="1" height="1" src="https://www.youtube.com/embed/lQN4rLETdJ8?start=31&autoplay=1" frameborder="0" allowfullscreen></iframe>
</body>

</html>
